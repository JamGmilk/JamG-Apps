package com.zzz.toClipboard;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		String share = intent.getStringExtra(Intent.EXTRA_TEXT);
		cm.setPrimaryClip(ClipData.newPlainText(null, share));
		Toast.makeText(this,"已复制",Toast.LENGTH_SHORT).show();
		finish();
	}
}
