package com.zzz.lockscreenroot;

import android.app.Activity;
import android.os.Bundle;
import java.io.*;

public class Main extends Activity {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		try {
			Runtime.getRuntime().exec("su /n input keyevent 26 \n");
		}
		catch (IOException e) {}
		finish();
    
	}
}
