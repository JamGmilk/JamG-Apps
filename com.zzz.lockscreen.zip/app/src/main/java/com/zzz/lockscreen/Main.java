package com.zzz.lockscreen;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class Main extends Activity {
    private DevicePolicyManager mDPM;
    private ComponentName mCN;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        mDPM = (DevicePolicyManager)getSystemService(Context.DEVICE_POLICY_SERVICE);
        mCN = new ComponentName(this, Admin.class);
		//mCN = new ComponentName(this, com.zzz.lockscreen.Admin.class);

        if(mDPM.isAdminActive(mCN)){
            mDPM.lockNow();
            finish();
        }else{
            activeManager();
        }
    }

    private void activeManager() {
        Intent i  = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mCN);
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "");
        startActivityForResult(i, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 0 && resultCode == Activity.RESULT_OK) {
            mDPM.lockNow();
            finish();
        } else activeManager();
        super.onActivityResult(requestCode, resultCode, data);
    }
}
