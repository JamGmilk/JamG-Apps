package com.zzz.lockscreen;

import android.app.admin.DeviceAdminReceiver;

public class Admin extends DeviceAdminReceiver {

}
